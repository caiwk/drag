# About Drummer #

Drummer is a component used in Dragonboat's tests. It has been moved into github.com/lni/dragonboat/internal in the coming release, your application is not suppose to import drummer.
