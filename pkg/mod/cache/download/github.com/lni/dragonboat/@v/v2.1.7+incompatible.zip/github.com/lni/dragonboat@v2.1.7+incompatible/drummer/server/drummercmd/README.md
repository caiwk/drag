# About dragonboat-drummer-cmd #

dragonboat-drummer-cmd is a command line tool used to interact with [Drummer](../../README.md). It can be used to - 
* Define and launch raft clusters during Drummer's launch phase. 
* Check how many nodehost instances are connected and what are their status. 
* Check raft cluster status. 
* Add or remove Drummer nodes.
