# About Drummer #

The drummer package is used for managing distributed NodeHost instances. It is used for monkey tests.
