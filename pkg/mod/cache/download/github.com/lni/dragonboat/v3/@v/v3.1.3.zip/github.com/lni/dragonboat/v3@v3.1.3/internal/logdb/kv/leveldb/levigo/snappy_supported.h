
#include <stdbool.h>

bool SnappyCompressionSupported();
