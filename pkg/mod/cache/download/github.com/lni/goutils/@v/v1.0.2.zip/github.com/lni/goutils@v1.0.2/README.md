## About ##
This repo contains the utility functions and types shared by [Dragonboat](https://github.com/lni/dragonboat) and its related projects. 

## License ##
Apache License Version 2.0. See LICENSE for details.

Third party code and their licenses is summarized [here](COPYRIGHT).
